import { Link } from "react-router-dom";
import useDocumentTitle from "@/hooks/useDocumentTitle";
import {
  ArrowRight,
  ClipboardList,
  Droplets,
  Lightbulb,
  MapPin,
  Recycle,
  ShieldCheck,
  TrafficCone,
  Timer,
  Building2,
} from "lucide-react";
import { PublicHeader, PublicFooter } from "@/components/layout/PublicLayout";
import Button from "@/components/common/Button";

const categories = [
  { icon: TrafficCone, label: "Potholes", desc: "Damaged roads and unsafe surfaces" },
  { icon: Recycle, label: "Garbage", desc: "Uncollected waste and dumping" },
  { icon: Droplets, label: "Water Leakage", desc: "Pipeline leaks and wastage" },
  { icon: Lightbulb, label: "Streetlights", desc: "Dark stretches and faulty poles" },
];

const steps = [
  { icon: MapPin, title: "Report with location", desc: "Add a photo, pick the exact spot on the map and describe the issue." },
  { icon: Building2, title: "Routed to a department", desc: "The complaint is reviewed and assigned to the responsible department and officer." },
  { icon: Timer, title: "Track until resolved", desc: "Follow every status change on a clear timeline until the work is complete." },
];

const benefits = [
  { icon: ClipboardList, title: "One record per issue", desc: "Every complaint carries an ID, department, officer and full update history." },
  { icon: ShieldCheck, title: "Accountable workflow", desc: "Officers and administrators work from the same status model as citizens see." },
  { icon: MapPin, title: "Location-first", desc: "Map-based reporting removes vague addresses and speeds up field work." },
];

function LandingPage() {
  useDocumentTitle("CivicPulse — Report and Track Civic Issues");
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <PublicHeader />
      <main className="flex-1">
        <section className="border-b border-border">
          <div className="mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:items-center lg:py-24">
            <div>
              <span className="inline-flex items-center rounded-full border border-border bg-secondary px-3 py-1 text-xs font-medium text-muted-foreground">
                Civic issue reporting &amp; management
              </span>
              <h1 className="mt-5 text-4xl font-semibold tracking-tight text-foreground sm:text-5xl">
                Report civic issues. Follow them to resolution.
              </h1>
              <p className="mt-4 max-w-xl text-base text-muted-foreground">
                CivicPulse connects citizens, department officers and municipal administrators on a
                single, transparent workflow — from the first photo to the final status update.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Button as={Link} to="/citizen/report" size="lg">
                  Report an Issue
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </Button>
                <Button as={Link} to="/citizen/complaints" variant="outline" size="lg">
                  Track Complaint
                </Button>
              </div>
            </div>

            <div className="card-surface p-6">
              <p className="text-sm font-medium text-muted-foreground">What can you report?</p>
              <ul className="mt-4 grid gap-3 sm:grid-cols-2">
                {categories.map(({ icon: Icon, label, desc }) => (
                  <li key={label} className="rounded-xl border border-border bg-secondary/40 p-4">
                    <Icon className="h-5 w-5 text-primary" aria-hidden="true" />
                    <p className="mt-2 text-sm font-semibold text-foreground">{label}</p>
                    <p className="mt-1 text-xs text-muted-foreground">{desc}</p>
                  </li>
                ))}
              </ul>
              <p className="mt-4 text-xs text-muted-foreground">
                Anything else fits under “Other civic issues”.
              </p>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
          <h2 className="text-2xl font-semibold tracking-tight text-foreground">How it works</h2>
          <ol className="mt-8 grid gap-5 md:grid-cols-3">
            {steps.map(({ icon: Icon, title, desc }, i) => (
              <li key={title} className="card-surface p-5">
                <div className="flex items-center gap-3">
                  <span className="grid h-9 w-9 place-items-center rounded-lg bg-secondary text-primary">
                    <Icon className="h-4 w-4" aria-hidden="true" />
                  </span>
                  <span className="text-xs font-medium text-muted-foreground">Step {i + 1}</span>
                </div>
                <h3 className="mt-4 text-base font-semibold text-foreground">{title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{desc}</p>
              </li>
            ))}
          </ol>
        </section>

        <section className="border-y border-border bg-card">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
            <h2 className="text-2xl font-semibold tracking-tight text-foreground">Why CivicPulse</h2>
            <div className="mt-8 grid gap-5 md:grid-cols-3">
              {benefits.map(({ icon: Icon, title, desc }) => (
                <div key={title} className="rounded-xl border border-border bg-background p-5">
                  <Icon className="h-5 w-5 text-primary" aria-hidden="true" />
                  <h3 className="mt-3 text-base font-semibold text-foreground">{title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
          <div className="card-surface flex flex-col items-start justify-between gap-4 p-8 sm:flex-row sm:items-center">
            <div>
              <h2 className="text-xl font-semibold text-foreground">Ready to report an issue?</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Create an account as a citizen, or sign in as an officer or administrator.
              </p>
            </div>
            <div className="flex gap-3">
              <Button as={Link} to="/register">
                Create account
              </Button>
              <Button as={Link} to="/login" variant="outline">
                Log in
              </Button>
            </div>
          </div>
        </section>
      </main>
      <PublicFooter />
    </div>
  );
}

export default LandingPage;

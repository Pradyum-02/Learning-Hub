import { Link, Outlet } from "react-router-dom";
import Logo from "./Logo";
import ThemeToggle from "./ThemeToggle";
import Button from "../common/Button";

export function PublicHeader() {
  return (
    <header className="sticky top-0 z-30 border-b border-border bg-background/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
        <Logo />
        <div className="flex items-center gap-2">
          <ThemeToggle />
          <Button as={Link} to="/login" variant="outline" size="sm">
            Log in
          </Button>
          <Button as={Link} to="/register" size="sm" className="hidden sm:inline-flex">
            Register
          </Button>
        </div>
      </div>
    </header>
  );
}

export function PublicFooter() {
  return (
    <footer className="border-t border-border bg-card">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:px-6 md:grid-cols-3">
        <div>
          <Logo />
          <p className="mt-3 max-w-xs text-sm text-muted-foreground">
            A civic issue reporting and management platform for citizens, officers and municipal
            administrators.
          </p>
        </div>
        <nav aria-label="Footer" className="text-sm">
          <h2 className="mb-3 font-semibold text-foreground">Platform</h2>
          <ul className="space-y-2 text-muted-foreground">
            <li>
              <Link to="/citizen/report" className="hover:text-foreground">
                Report an issue
              </Link>
            </li>
            <li>
              <Link to="/citizen/complaints" className="hover:text-foreground">
                Track complaints
              </Link>
            </li>
            <li>
              <Link to="/login" className="hover:text-foreground">
                Officer / Admin login
              </Link>
            </li>
          </ul>
        </nav>
        <div className="text-sm">
          <h2 className="mb-3 font-semibold text-foreground">Departments</h2>
          <ul className="space-y-2 text-muted-foreground">
            <li>Roads</li>
            <li>Sanitation</li>
            <li>Water Supply</li>
            <li>Electrical</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border py-4 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} CivicPulse. Academic project build.
      </div>
    </footer>
  );
}

export default function PublicLayout() {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <PublicHeader />
      <main className="flex-1">
        <Outlet />
      </main>
      <PublicFooter />
    </div>
  );
}
